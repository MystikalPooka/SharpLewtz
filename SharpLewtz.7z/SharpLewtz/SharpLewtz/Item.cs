﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpLewtz
{
    class Item
    {
        int bonus = 0;
        int cost;


        public Item()
        {

        }

        public Item(string path)
        {

        }

        bool isEnabled { get; set; }

        public event EventHandler hit;
    }
}
