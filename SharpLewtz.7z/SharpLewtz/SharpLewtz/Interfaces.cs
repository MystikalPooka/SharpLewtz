﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpLewtz
{
    public interface IObject
    {
        #region FIELDS

        string objectType { get; set; } //"gem" "weapon table"
        bool isEnabled    { get; set; } 
        int Probability   { get; set; }
        bool Always       { get; set; } //is this always enabled?

        LootTable parentTable { get; set; } //owner of this object
        #endregion

        #region EVENTS
        event EventHandler hit;
        #endregion
    }

    public interface ITable : IObject
    {
        int rollCount { get; set; } //total amount of "things" returned from this table is <= count

        IEnumerable<IObject> contents { get; set; }

        IEnumerable<IObject> results { get; } //the full result set that is returned to things (and sometimes stuff)
    }
}
