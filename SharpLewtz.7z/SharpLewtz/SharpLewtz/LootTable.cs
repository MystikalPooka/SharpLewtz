﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SharpLewtz
{
    //Each time another table is added, add 100 to every value in that table and add the entries to the end of the contents
    //of the current table(s)
    //then roll (table) * d100 (roll 0-100)
    public class LootTable : ITable
    {
        private string path;
        //private ListView contents

        

        public LootTable(string path)
        {
            LoadFromFile(path);
        }

        public ListView LoadFromFile(string path)
        {
            ListView lv = new ListView();
            using (StreamReader file = new StreamReader(path))
            {
                string str;
                while ((str = file.ReadLine()) != null)
                {
                    string[] strArray;

                    strArray = str.Split(',');

                    ListViewItem listItem = new ListViewItem(strArray[0]); //name
                    

                    for (int i = 1; i < strArray.Length; ++i)
                    {
                        listItem.SubItems.Add(strArray[i]); //(strArray[i]);
                    }
                    lv.Items.Add(listItem); //(listItem);
                }
            }
            /*for (int j = 0; j < lv.Items.Count; j++)
            {
                for (int p = 0; p < lv.Items[j].SubItems.Count; p++)
                {
                    MessageBox.Show("lv " + p + " " + lv.Items[j].SubItems[p].Text);
                }
            }*/
            return lv;
        }

        public LootTable()
        {
        }

        public int rollCount { get; set; }
        public IEnumerable<IObject> contents { get; set; }

        //private IEnumerable<IObject> _Results;
        public IEnumerable<IObject> results { get; set; } //TODO: this should be { get; }

        private string _objectType;
        public string objectType { get; set; }
        public bool isEnabled    { get; set; }
        public int Probability   { get; set; }
        public bool Always       { get; set; }

        public LootTable parentTable { get; set; }

        public event EventHandler hit;
    }
}
