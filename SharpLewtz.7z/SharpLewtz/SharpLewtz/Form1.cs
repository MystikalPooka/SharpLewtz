﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SharpLewtz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LootTable testTable = new LootTable();
            //listView1.Items.AddRange(new ListViewItem[]{item1,item2,item3});
            //listView1.Columns.Add("FUCKING WORK YOU ASSDICK");
            listView1.Clear();

            listView1 = testTable.LoadFromFile("Tables\\Common Armors.Lewt");

            //listView1.Items.Add("Bitch").SubItems.AddRange(row1);
            //listView1.Items.Add("Fuck");//new LootTable("Tables\\Common Armors.Lewt"));// bitchTable.LoadFromFile("Tables\\Common Armors.Lewt");
            listView1.Update();

            for (int j = 0; j < listView1.Items.Count; j++)
            {
                for (int p = 0; p < listView1.Items[j].SubItems.Count; p++)
                {
                    MessageBox.Show(j + ": " + p + " " + listView1.Items[j].SubItems[p].Text);
                }
            }
            listView1.Items[0].Text = "Fuck";
        }

        private void btnAddTreasure_Click(object sender, EventArgs e)
        {
            InputControl li = new InputControl();
            flowLayoutPanel1.Controls.Add(li);
        }

        private void btnRemoveTreasure_Click(object sender, EventArgs e)
        {
            if (flowLayoutPanel1.Controls.Count > 2)
            {
                //textBox1.Text += flowLayoutPanel1.Controls.Count.ToString();
                flowLayoutPanel1.Controls.RemoveAt(flowLayoutPanel1.Controls.Count - 1);
            }
        }

        private void GenerateLootButton_Click(object sender, EventArgs e)
        {
            //string shitTitFuckAssBitch = "\r\n MOO";
            //var v = new InputControl();
            int counter = 0;
            foreach(Control c in flowLayoutPanel1.Controls)
            {
                if (c is InputControl)
                {
                    ++counter;
                    //textBox2.Text += "\r\n fuck tits ass wipe";

                    InputControl ic = (InputControl)c;

                    if(ic.count > 0 && ic.isChecked)
                    {
                        //roll on the tables (for)
                    }
                    //LootTable b = new LootTable("fuck");

                    

                    //b.add
                    /*/---->#DICKBUG CODE<----
                    textBox1.Text += "\r\n MOO" + counter + "8=";
                        for(int i = 0; i < ic.count; ++i)
                        {
                            textBox1.Text += "=";
                        }
                        textBox1.Text += "D";
                    //DO SHEETS.
                    //like the laundry.*/
                }
            }
        }
    }
}
